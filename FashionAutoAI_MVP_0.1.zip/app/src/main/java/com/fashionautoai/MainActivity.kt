package com.fashionautoai

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.UUID

data class Product(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val category: String,
    val price: String,
    val commission: String,
    val link: String,
    val schedule: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FashionAutoAIApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FashionAutoAIApp() {
    var tab by remember { mutableStateOf(0) }
    var products by remember { mutableStateOf(listOf<Product>()) }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Fashion Auto AI") },
                    subtitle = { Text("Meesho Fashion Affiliate") }
                )
            },
            bottomBar = {
                NavigationBar {
                    listOf("Home", "Products", "Schedule", "Settings").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = { Text(if (i == 0) "⌂" else if (i == 1) "🛍" else if (i == 2) "◷" else "⚙") },
                            label = { Text(label) }
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize()) {
                when (tab) {
                    0 -> HomeScreen(products)
                    1 -> ProductScreen(products) { products = products + it }
                    2 -> ScheduleScreen(products)
                    3 -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
fun HomeScreen(products: List<Product>) {
    Column(Modifier.padding(20.dp)) {
        Text("🚀 Your affiliate dashboard", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("Today’s target: 5 products")
        Spacer(Modifier.height(20.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(18.dp)) {
                Text("Workflow", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("📸 Upload → 🤖 AI Photo → ✍️ Caption → 🎙 Hindi Reel → 🔗 Affiliate Link → 📅 Schedule → Instagram")
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Saved products: ${products.size}")
        Text("Commission rule: only 4%+ products")
    }
}

@Composable
fun ProductScreen(products: List<Product>, onAdd: (Product) -> Unit) {
    var showForm by remember { mutableStateOf(false) }
    Column(Modifier.padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Products", style = MaterialTheme.typography.headlineSmall)
            Button(onClick = { showForm = true }) { Text("+ Add") }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(products) { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp)) {
                        Text(p.name, style = MaterialTheme.typography.titleMedium)
                        Text("${p.category} • ₹${p.price} • ${p.commission}% commission")
                        Text("Schedule: ${p.schedule}")
                        if (p.link.isNotBlank()) Text("Affiliate link saved ✓")
                    }
                }
            }
        }
    }
    if (showForm) {
        AddProductDialog(
            onDismiss = { showForm = false },
            onSave = { onAdd(it); showForm = false }
        )
    }
}

@Composable
fun AddProductDialog(onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Kurti") }
    var price by remember { mutableStateOf("") }
    var commission by remember { mutableStateOf("") }
    var link by remember { mutableStateOf("") }
    var schedule by remember { mutableStateOf("Not scheduled") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Product name") })
                OutlinedTextField(category, { category = it }, label = { Text("Category") })
                OutlinedTextField(price, { price = it }, label = { Text("Price") })
                OutlinedTextField(commission, { commission = it }, label = { Text("Commission %") })
                OutlinedTextField(link, { link = it }, label = { Text("Meesho affiliate link") })
                OutlinedTextField(schedule, { schedule = it }, label = { Text("Schedule e.g. 09:00 AM") })
            }
        },
        confirmButton = {
            Button(
                enabled = name.isNotBlank() && (commission.toDoubleOrNull() ?: 0.0) >= 4.0,
                onClick = {
                    onSave(Product(name=name, category=category, price=price, commission=commission, link=link, schedule=schedule))
                }
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
fun ScheduleScreen(products: List<Product>) {
    Column(Modifier.padding(20.dp)) {
        Text("Schedule", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("Suggested daily test schedule:")
        Text("09:00 AM  • Kurti")
        Text("11:30 AM  • Kurta Set")
        Text("02:00 PM  • Dress")
        Text("05:30 PM  • Saree")
        Text("08:00 PM  • Jewellery")
        Spacer(Modifier.height(18.dp))
        Text("Scheduled products: ${products.count { it.schedule != "Not scheduled" }}")
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.padding(20.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("AI Photo Generator: Not connected")
        Text("OpenAI API: Add later")
        Text("Instagram/Meta API: Add later")
        Text("Auto-DM: You will manage separately")
        Spacer(Modifier.height(16.dp))
        Text("Important: Instagram publishing will use official Meta authorization; never store your Instagram password in this app.")
    }
}
