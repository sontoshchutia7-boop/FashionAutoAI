# Fashion Auto AI — MVP 0.1

Android starter app for a Meesho fashion affiliate workflow.

Current MVP:
- Home dashboard
- Product entry
- 4%+ commission validation
- Affiliate link field
- Schedule field
- Product list
- Settings placeholders for AI and Instagram integrations

Next integration stages:
1. Product image picker
2. AI image generation
3. Caption + Hindi Reel script generation
4. Local persistent database
5. Official Meta/Instagram publishing
6. Comment/DM automation integration

Build:
- Open this folder in Android Studio.
- Sync Gradle.
- Run on an Android device/emulator.
